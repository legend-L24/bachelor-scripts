#!/usr/bin/bash

num=90

for i in $(seq 10 1 10)
do
	#mkdir ${i}
	cp ./xyz_in3.py ${i}
	for j in $(seq 1 1 10)
	do
		echo $num	
		cat config.sh > ${i}/job${j}.sh 
		Mystring="
cp geometry_${num}.in.next_step geometry.in
cp control_${num}.in control.in
cp hessian_${num}.aims hessian.aims
srun -n 288 aims.210716_2.mpi.x > aims.out
mv aims.out output_2_${num}
"
		let num++
		echo "${Mystring}" >> ${i}/job${j}.sh
	done
	cd ${i}
	echo "begin to build basis"
	./xyz_in3.py
	nohup ../dependency.sh & >> ../job.txt
	echo "finish to build "
	cd ..
done
