#!/bin/bash

#SBATCH -o ./tjob.out.%j        #Standard output
#SBATCH -e ./tjob.err.%j        #Error output
#SBATCH -D ./                   #Initial working directory
#SBATCH -J aimsreg              #Job name
#SBATCH --nodes=4               #Nr. of compute nodes
#SBATCH --ntasks=288             #Nr. of MPI processes for the job
#SBATCH --ntasks-per-core=1     #Nr. of threads per MPI process; set always to 1
#SBATCH --mem=120000              #Memory in MB
#SBATCH --mail-type=none
#SBATCH --mail-user=vondrak@fhi-berlin.mpg.de
#SBATCH --time=24:00:00         #Wall clock time; max = 24:00:00

export OMP_NUM_THREADS=1        #Disables OpenMP multi-threading
export MKL_DYNAMIC=FALSE        #Disables MKL (Math Kernel Library) to dynamically change the number of threads
export MKL_NUM_THREADS=1        #Disable MKL multi-threading

#Load compiler and modules
module purge                    #To start at the root of the environment modules hierarchy
module load intel/21.4.0       #Intel Fortran compiler: currently recommended version (Feb 2021) by MPCDF on Raven: intel/19.1.2
module load mkl/2021.4          #Intel MKL
module load impi/2021.4        #Intel MPI: currently recommended version (Feb 2021) by MPCDF on Raven: impi/2019.8
module load gcc/11
module load anaconda    #Manage python packages: currently (Feb 2021) official supported python environment by MPCDF: anaconda/3/2020.02
module load fhiaims/210716


cp geometry_93.in geometry.in
cp control_93.in control.in
srun -n 288 aims.210716_2.mpi.x > aims.out
mv aims.out output__93
mv geometry.in.next_step geometry_93.in.next_step
mv hessian.aims hessian_93.aims

