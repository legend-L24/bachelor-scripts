#!/usr/bin/bash

num=0

for i in $(seq 1 1 15)
do
	mkdir ${i}
	cp ./xyz_in2.py ${i}
	for j in $(seq 1 1 10)
	do
		echo $num	
		cat config.sh > ${i}/job${j}.sh 
		Mystring="
cp geometry_${num}.in geometry.in
cp control_${num}.in control.in
srun -n 72 aims.210716_2.mpi.x > aims.out
mv aims.out output__${num}
mv geometry.in.next_step geometry_${num}.in.next_step
mv hessian.aims hessian_${num}.aims
"
		let num++
		echo "${Mystring}" >> ${i}/job${j}.sh
	done
	cd ${i}
	echo "begin to build basis"
	./xyz_in2.py
	nohup ../dependency.sh & >> ../job.txt
	echo "finish to build "
	cd ..
done
