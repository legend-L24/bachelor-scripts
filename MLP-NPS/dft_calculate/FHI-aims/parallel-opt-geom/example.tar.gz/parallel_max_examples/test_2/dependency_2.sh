#! /bin/bash

# first job - no dependencies
jid1=$(sbatch --mem=120000 --time=24:00:00 job1.sh | cut -d' ' -f4 )
# multiple jobs can depend on a single job
jid2=$(sbatch --mem=120000  --time=24:00:00 --dependency=afterany:$jid1 job2.sh | cut -d' ' -f4 )
#jid3=$(sbatch --mem=120000  --time=24:00:00 --dependency=afterany:$jid2 job3.sh | cut -d' ' -f4 )
#jid4=$(sbatch --mem=120000  --time=24:00:00 --dependency=afterany:$jid3 job4.sh | cut -d' ' -f4 )
#jid5=$(sbatch --mem=120000  --time=24:00:00 --dependency=afterany:$jid4 job5.sh | cut -d' ' -f4 )
#jid6=$(sbatch --mem=120000  --time=24:00:00 --dependency=afterany:$jid5 job6.sh | cut -d' ' -f4 )
#jid7=$(sbatch --mem=120000  --time=24:00:00 --dependency=afterany:$jid6 job7.sh | cut -d' ' -f4 )
#jid8=$(sbatch --mem=120000  --time=24:00:00 --dependency=afterany:$jid7 job8.sh | cut -d' ' -f4 )
#jid9=$(sbatch --mem=120000  --time=24:00:00 --dependency=afterany:$jid8 job9.sh | cut -d' ' -f4 )
sbatch  --mem=120000 --time=24:00:00 --dependency=afterany:$jid2 job3.sh

