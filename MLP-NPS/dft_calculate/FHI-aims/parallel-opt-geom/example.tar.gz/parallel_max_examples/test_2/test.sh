#!/usr/bin/bash
name = "test"
num = 5
echo $num
echo $name
