#!/usr/bin/bash

num=0
mkdir result
for i in $(seq 1 1 15)
do
	cp ${i}/output_2_* result
done
