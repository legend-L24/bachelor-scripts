#!/usr/bin/bash
for i in $(seq 1 1 16)
do
        rm -rf ${i}
done
